<!-- judul -->
<div class="panel">
    <div class="panel-middle" id="judul">
        <img src="asset/image/beranda.svg">
        <div id="judul-text">
            <h2 class="text-green">BERANDA</h2>
            Halamanan Utama Administrator
        </div>
    </div>
</div>
<!-- judul -->
<div class="panel">
    <div class="panel-middle text-center">
        <h1>
            Selamat Datang, <span class="text-green">Administrator</span><br>
            di Sistem Pendukung Keputusan pemilihan supplier berbasis web menggunakan metode <span class="text-green">Simple Additive Weighting</span>
        </h1>
    </div>
    <div class="panel-bottom"></div>
</div>